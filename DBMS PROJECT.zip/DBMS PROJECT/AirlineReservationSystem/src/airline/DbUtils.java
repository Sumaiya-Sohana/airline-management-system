package airline;

import javax.swing.table.AbstractTableModel;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DbUtils {
    
    public static class ResultSetTableModel extends AbstractTableModel {
        private List<String> columnNames = new ArrayList<>();
        private List<List<Object>> data = new ArrayList<>();
        
        public ResultSetTableModel(ResultSet rs) throws SQLException {
            ResultSetMetaData metaData = rs.getMetaData();
            
            // Get column names
            int columnCount = metaData.getColumnCount();
            for (int i = 1; i <= columnCount; i++) {
                columnNames.add(metaData.getColumnName(i));
            }
            
            // Get data
            while (rs.next()) {
                List<Object> row = new ArrayList<>();
                for (int i = 1; i <= columnCount; i++) {
                    row.add(rs.getObject(i));
                }
                data.add(row);
            }
        }
        
        @Override 
        public int getRowCount() { return data.size(); }
        
        @Override 
        public int getColumnCount() { return columnNames.size(); }
        
        @Override 
        public Object getValueAt(int row, int col) { return data.get(row).get(col); }
        
        @Override 
        public String getColumnName(int col) { return columnNames.get(col); }
        
        @Override
        public boolean isCellEditable(int row, int column) { return false; }
    }
    
    public static ResultSetTableModel resultSetToTableModel(ResultSet rs) throws SQLException {
        return new ResultSetTableModel(rs);
    }
    
    public static boolean testConnection() {
        try (Connection conn = DBConnection.getConnection()) {
            return conn.isValid(2);
        } catch (SQLException ex) {
            return false;
        }
    }
}