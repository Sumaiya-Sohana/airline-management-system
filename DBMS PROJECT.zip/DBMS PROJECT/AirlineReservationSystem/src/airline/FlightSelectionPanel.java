package airline;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Vector;

public class FlightSelectionPanel extends JPanel {
    private JComboBox<String> fromCombo, toCombo;
    private JTable flightTable;
    private JLabel noFlightsLabel;
    private MainApplication mainApp;
    
    public FlightSelectionPanel(MainApplication mainApp) {
        this.mainApp = mainApp;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JLabel header = new JLabel("Flight Selection", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(new Color(0, 102, 204));
        add(header, BorderLayout.NORTH);
        
        // Search panel
        JPanel searchPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        
        // From combo
        searchPanel.add(new JLabel("Departure Airport: *"));
        fromCombo = new JComboBox<>();
        fromCombo.addItem("-- Select Airport --");
        loadAirports(fromCombo);
        searchPanel.add(fromCombo);
        
        // To combo
        searchPanel.add(new JLabel("Arrival Airport: *"));
        toCombo = new JComboBox<>();
        toCombo.addItem("-- Select Airport --");
        loadAirports(toCombo);
        searchPanel.add(toCombo);
        
        add(searchPanel, BorderLayout.NORTH);
        
        // Table for flights
        flightTable = new JTable();
        flightTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scrollPane = new JScrollPane(flightTable);
        
        // No flights label
        noFlightsLabel = new JLabel("No flights found matching your criteria", SwingConstants.CENTER);
        noFlightsLabel.setVisible(false);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> mainApp.showPanel("passenger"));
        
        JButton searchBtn = new JButton("Search Flights");
        searchBtn.addActionListener(new SearchFlightsListener());
        
        JButton selectBtn = new JButton("Select Flight");
        selectBtn.addActionListener(new SelectFlightListener());
        
        buttonPanel.add(backBtn);
        buttonPanel.add(searchBtn);
        buttonPanel.add(selectBtn);
        
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    public void resetForm() {
        fromCombo.setSelectedIndex(0);
        toCombo.setSelectedIndex(0);
        flightTable.setModel(new DefaultTableModel());
        noFlightsLabel.setVisible(false);
    }
    
    private void loadAirports(JComboBox<String> combo) {
        combo.removeAllItems();
        combo.addItem("-- Select Airport --");
        
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT Code, Name || ' (' || City || ', ' || Country || ')' AS Display FROM Airport ORDER BY Country, City";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);  // Fixed: Added SQL parameter
            
            while (rs.next()) {
                combo.addItem(rs.getString("Code") + " - " + rs.getString("Display"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "Error loading airports: " + ex.getMessage(),  // Fixed: Added closing parenthesis
                "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private class SearchFlightsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (fromCombo.getSelectedIndex() == 0 || toCombo.getSelectedIndex() == 0) {
                JOptionPane.showMessageDialog(FlightSelectionPanel.this,
                    "Please select both departure and arrival airports",
                    "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            String from = fromCombo.getSelectedItem().toString().split(" - ")[0];
            String to = toCombo.getSelectedItem().toString().split(" - ")[0];
            
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "SELECT f.FlightID, a1.Name AS FromAirport, a2.Name AS ToAirport, " +
                           "TO_CHAR(f.Departure, 'DD-MON-YYYY HH24:MI') AS Departure, " +
                           "TO_CHAR(f.Arrival, 'DD-MON-YYYY HH24:MI') AS Arrival, " +
                           "f.Base_Price, f.Status, ap.Model " +
                           "FROM Flight f " +
                           "JOIN Airport a1 ON f.FromAirport = a1.Code " +
                           "JOIN Airport a2 ON f.ToAirport = a2.Code " +
                           "JOIN Airplane ap ON f.AID = ap.AID " +
                           "WHERE f.FromAirport = ? AND f.ToAirport = ? " +
                           "AND f.Status = 'Scheduled' " +
                           "ORDER BY f.Departure";
                
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, from);
                pstmt.setString(2, to);
                
                ResultSet rs = pstmt.executeQuery();
                
                DefaultTableModel model = new DefaultTableModel();
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                
                for (int i = 1; i <= columnCount; i++) {
                    model.addColumn(metaData.getColumnName(i));
                }
                
                boolean hasResults = false;
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    for (int i = 1; i <= columnCount; i++) {
                        row.add(rs.getObject(i));
                    }
                    model.addRow(row);
                    hasResults = true;
                }
                
                flightTable.setModel(model);
                noFlightsLabel.setVisible(!hasResults);
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(FlightSelectionPanel.this,
                    "Error searching flights: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private class SelectFlightListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = flightTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(FlightSelectionPanel.this,
                    "Please select a flight first", "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            try {
                int flightId = Integer.parseInt(flightTable.getModel().getValueAt(selectedRow, 0).toString());
                ReservationData.setSelectedFlightId(flightId);
                mainApp.showPanel("payment");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(FlightSelectionPanel.this,
                    "Error selecting flight: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}