package airline;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class PassengerInfoPanel extends JPanel {
    private JTextField nameField, phoneField, emailField, cityField, passportField;
    private JComboBox<String> dayCombo, monthCombo, yearCombo, genderCombo, nationalityCombo;
    private MainApplication mainApp;
    
    public PassengerInfoPanel(MainApplication mainApp) {
        this.mainApp = mainApp;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JLabel header = new JLabel("Passenger Information", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(new Color(0, 102, 204));
        add(header, BorderLayout.NORTH);
        
        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(9, 2, 10, 10));
        
        // Name field
        formPanel.add(new JLabel("Full Name: *"));
        nameField = new JTextField();
        formPanel.add(nameField);
        
        // Phone field
        formPanel.add(new JLabel("Phone Number: *"));
        phoneField = new JTextField();
        formPanel.add(phoneField);
        
        // Email field
        formPanel.add(new JLabel("Email: *"));
        emailField = new JTextField();
        formPanel.add(emailField);
        
        // City field
        formPanel.add(new JLabel("City:"));
        cityField = new JTextField();
        formPanel.add(cityField);
        
        // Gender
        formPanel.add(new JLabel("Gender:"));
        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});
        formPanel.add(genderCombo);
        
        // Passport
        formPanel.add(new JLabel("Passport Number:"));
        passportField = new JTextField();
        formPanel.add(passportField);
        
        // Nationality
        formPanel.add(new JLabel("Nationality:"));
        nationalityCombo = new JComboBox<>(new String[]{"USA", "UK", "Canada", "Australia", "India", "Japan", "Other"});
        formPanel.add(nationalityCombo);
        
        // Date of Birth
        formPanel.add(new JLabel("Date of Birth:"));
        JPanel dobPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        dayCombo = new JComboBox<>();
        for (int i = 1; i <= 31; i++) dayCombo.addItem(String.valueOf(i));
        
        monthCombo = new JComboBox<>();
        String[] months = {"January", "February", "March", "April", "May", "June",
                          "July", "August", "September", "October", "November", "December"};
        for (String month : months) monthCombo.addItem(month);
        
        yearCombo = new JComboBox<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = currentYear; i >= 1900; i--) yearCombo.addItem(String.valueOf(i));
        
        dobPanel.add(dayCombo);
        dobPanel.add(monthCombo);
        dobPanel.add(yearCombo);
        formPanel.add(dobPanel);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> mainApp.showPanel("welcome"));
        
        JButton nextBtn = new JButton("Save & Continue");
        nextBtn.setBackground(new Color(0, 102, 204));
        nextBtn.setForeground(Color.WHITE);
        nextBtn.addActionListener(new SavePassengerListener());
        
        buttonPanel.add(backBtn);
        buttonPanel.add(nextBtn);
        
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    public void resetForm() {
        nameField.setText("");
        phoneField.setText("");
        emailField.setText("");
        cityField.setText("");
        passportField.setText("");
        genderCombo.setSelectedIndex(0);
        nationalityCombo.setSelectedIndex(0);
        dayCombo.setSelectedIndex(0);
        monthCombo.setSelectedIndex(0);
        yearCombo.setSelectedIndex(0);
    }
    
    private class SavePassengerListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!validateInputs()) return;
            
            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO Passenger (Pname, Phone, DOB, City, Email, Gender, PassportNo, Nationality) " +
                            "VALUES (?, ?, TO_DATE(?, 'DD-MON-YYYY'), ?, ?, ?, ?, ?)";
                
                PreparedStatement pstmt = conn.prepareStatement(sql, new String[]{"PID"});
                
                pstmt.setString(1, nameField.getText().trim());
                pstmt.setString(2, phoneField.getText().trim());
                
                // Format DOB
                String dob = dayCombo.getSelectedItem() + "-" + 
                             monthCombo.getSelectedItem().toString().substring(0, 3) + "-" + 
                             yearCombo.getSelectedItem();
                pstmt.setString(3, dob);
                
                pstmt.setString(4, cityField.getText().trim());
                pstmt.setString(5, emailField.getText().trim());
                pstmt.setString(6, genderCombo.getSelectedItem().toString());
                pstmt.setString(7, passportField.getText().trim());
                pstmt.setString(8, nationalityCombo.getSelectedItem().toString());
                
                pstmt.executeUpdate();
                
                // Get generated PID
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    ReservationData.setPassengerId(rs.getInt(1));
                }
                
                mainApp.showPanel("flight");
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(PassengerInfoPanel.this,
                    "Error saving passenger: " + ex.getMessage(), "Database Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
        
        private boolean validateInputs() {
            if (nameField.getText().trim().isEmpty()) {
                showError("Please enter your full name");
                return false;
            }
            
            if (phoneField.getText().trim().isEmpty()) {
                showError("Please enter your phone number");
                return false;
            }
            
            if (!phoneField.getText().matches("\\d{10,15}")) {
                showError("Phone number must be 10-15 digits");
                return false;
            }
            
            if (emailField.getText().trim().isEmpty()) {
                showError("Please enter your email address");
                return false;
            }
            
            if (!emailField.getText().matches("^[\\w-.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                showError("Please enter a valid email address");
                return false;
            }
            
            return true;
        }
        
        private void showError(String message) {
            JOptionPane.showMessageDialog(PassengerInfoPanel.this,
                message, "Validation Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}