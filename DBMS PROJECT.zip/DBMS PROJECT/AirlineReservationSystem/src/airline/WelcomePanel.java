package airline;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WelcomePanel extends JPanel {
    private MainApplication mainApp;
    
    public WelcomePanel(MainApplication mainApp) {
        this.mainApp = mainApp;
        setLayout(new BorderLayout(10, 20));
        setBackground(new Color(30, 144, 255));
        setBorder(BorderFactory.createEmptyBorder(40, 20, 40, 20));
        
        // Title Panel
        JPanel titlePanel = new JPanel(new GridLayout(2, 1, 0, 10));
        titlePanel.setOpaque(false);
        
        JLabel titleLabel = new JLabel("Welcome to SkyWings Airlines", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        
        JLabel subLabel = new JLabel("Your journey begins here...", SwingConstants.CENTER);
        subLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        subLabel.setForeground(Color.WHITE);
        
        titlePanel.add(titleLabel);
        titlePanel.add(subLabel);
        
        // Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        
        JButton startButton = new JButton("Start New Booking");
        startButton.setFont(new Font("Arial", Font.BOLD, 18));
        startButton.setBackground(new Color(255, 255, 255));
        startButton.setForeground(new Color(30, 144, 255));
        startButton.setPreferredSize(new Dimension(200, 50));
        startButton.addActionListener(e -> mainApp.showPanel("passenger"));
        
        buttonPanel.add(startButton);
        
        // Add components to main panel
        add(titlePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}