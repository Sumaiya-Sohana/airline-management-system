package airline;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PaymentPanel extends JPanel {
    private JComboBox<String> methodCombo;
    private JTextField amountField, cardField, cvvField, expiryField;
    private MainApplication mainApp;
    
    public PaymentPanel(MainApplication mainApp) {
        this.mainApp = mainApp;
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JLabel header = new JLabel("Payment Information", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(new Color(0, 102, 204));
        add(header, BorderLayout.NORTH);
        
        // Form panel
        JPanel formPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        
        // Payment method
        formPanel.add(new JLabel("Payment Method: *"));
        methodCombo = new JComboBox<>(new String[]{"Credit Card", "Debit Card", "Net Banking", "UPI", "Cash"});
        methodCombo.addActionListener(e -> updatePaymentFields());
        formPanel.add(methodCombo);
        
        // Amount (calculated from flight)
        formPanel.add(new JLabel("Amount:"));
        amountField = new JTextField();
        amountField.setEditable(false);
        formPanel.add(amountField);
        
        // Card number
        formPanel.add(new JLabel("Card Number: *"));
        cardField = new JTextField();
        formPanel.add(cardField);
        
        // CVV
        formPanel.add(new JLabel("CVV: *"));
        cvvField = new JTextField();
        formPanel.add(cvvField);
        
        // Expiry date
        formPanel.add(new JLabel("Expiry Date (MM/YY): *"));
        expiryField = new JTextField();
        formPanel.add(expiryField);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        
        // Back button
        JButton backBtn = new JButton("Back");
        backBtn.addActionListener(e -> mainApp.showPanel("flight"));
        
        // Pay button
        JButton payBtn = new JButton("Complete Payment");
        payBtn.setBackground(new Color(0, 153, 51));
        payBtn.setForeground(Color.WHITE);
        payBtn.addActionListener(new ProcessPaymentListener());
        
        buttonPanel.add(backBtn);
        buttonPanel.add(payBtn);
        
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Initialize with flight price
        loadFlightPrice();
        updatePaymentFields();
    }
    
    public void resetForm() {
        methodCombo.setSelectedIndex(0);
        cardField.setText("");
        cvvField.setText("");
        expiryField.setText("");
        loadFlightPrice();
    }
    
    private void loadFlightPrice() {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT Base_Price FROM Flight WHERE FlightID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, ReservationData.getSelectedFlightId());
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                amountField.setText(String.format("%.2f", rs.getDouble("Base_Price")));
            } else {
                amountField.setText("0.00");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                "Error loading flight price: " + ex.getMessage(), "Database Error",
                JOptionPane.ERROR_MESSAGE);
            amountField.setText("0.00");
        }
    }
    
    private void updatePaymentFields() {
        String method = methodCombo.getSelectedItem().toString();
        boolean cardPayment = method.equals("Credit Card") || method.equals("Debit Card");
        
        cardField.setEnabled(cardPayment);
        cvvField.setEnabled(cardPayment);
        expiryField.setEnabled(cardPayment);
        
        if (!cardPayment) {
            cardField.setText("");
            cvvField.setText("");
            expiryField.setText("");
        }
    }
    
    private class ProcessPaymentListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (!validatePayment()) return;
            
            try (Connection conn = DBConnection.getConnection()) {
                conn.setAutoCommit(false);
                
                try {
                    // 1. Create reservation
                    String resSql = "INSERT INTO Reservation (Status, Total_Amount) VALUES (?, ?)";
                    PreparedStatement resStmt = conn.prepareStatement(resSql, new String[]{"RID"});
                    resStmt.setString(1, "Confirmed");
                    resStmt.setDouble(2, Double.parseDouble(amountField.getText()));
                    resStmt.executeUpdate();
                    
                    // Get generated RID
                    int rid = -1;
                    ResultSet rs = resStmt.getGeneratedKeys();
                    if (rs.next()) rid = rs.getInt(1);
                    
                    // 2. Link passenger to reservation
                    String linkSql = "INSERT INTO Reservation_Passenger (RID, PID) VALUES (?, ?)";
                    PreparedStatement linkStmt = conn.prepareStatement(linkSql);
                    linkStmt.setInt(1, rid);
                    linkStmt.setInt(2, ReservationData.getPassengerId());
                    linkStmt.executeUpdate();
                    
                    // 3. Create payment
                    String paySql = "INSERT INTO Payment (RID, Amount, Method, TransactionID, " +
                                    "Status, Card_Last_Four, Payment_Gateway) " +
                                    "VALUES (?, ?, ?, ?, 'Completed', ?, ?)";
                    PreparedStatement payStmt = conn.prepareStatement(paySql);
                    
                    payStmt.setInt(1, rid);
                    payStmt.setDouble(2, Double.parseDouble(amountField.getText()));
                    payStmt.setString(3, methodCombo.getSelectedItem().toString());
                    
                    // Generate transaction ID
                    String transactionId = "TXN" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
                    if (cardField.getText().length() >= 4) {
                        transactionId += cardField.getText().substring(cardField.getText().length() - 4);
                    }
                    payStmt.setString(4, transactionId);
                    
                    // Last 4 digits of card if applicable
                    if (cardField.getText().length() >= 4) {
                        payStmt.setString(5, cardField.getText().substring(cardField.getText().length() - 4));
                    } else {
                        payStmt.setNull(5, java.sql.Types.VARCHAR);
                    }
                    
                    payStmt.setString(6, "SkyWings Payment Gateway");
                    payStmt.executeUpdate();
                    
                    // 4. Create ticket
                    String ticketSql = "INSERT INTO Ticket (RID, FlightID, SeatNo, Class, Price, Status) " +
                                      "VALUES (?, ?, ?, ?, ?, 'Booked')";
                    PreparedStatement ticketStmt = conn.prepareStatement(ticketSql);
                    
                    ticketStmt.setInt(1, rid);
                    ticketStmt.setInt(2, ReservationData.getSelectedFlightId());
                    ticketStmt.setString(3, generateSeatNumber());
                    ticketStmt.setString(4, "Economy"); // Default class
                    ticketStmt.setDouble(5, Double.parseDouble(amountField.getText()));
                    
                    ticketStmt.executeUpdate();
                    
                    conn.commit();
                    
                    ReservationData.setReservationId(rid);
                    mainApp.showPanel("confirmation");
                    
                } catch (SQLException ex) {
                    conn.rollback();
                    throw ex;
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(PaymentPanel.this,
                    "Error processing payment: " + ex.getMessage(), "Payment Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
        
        private boolean validatePayment() {
            String method = methodCombo.getSelectedItem().toString();
            boolean cardPayment = method.equals("Credit Card") || method.equals("Debit Card");
            
            if (cardPayment) {
                if (cardField.getText().trim().isEmpty()) {
                    showError("Please enter your card number");
                    return false;
                }
                
                if (!cardField.getText().matches("\\d{13,16}")) {
                    showError("Card number must be 13-16 digits");
                    return false;
                }
                
                if (cvvField.getText().trim().isEmpty()) {
                    showError("Please enter the CVV code");
                    return false;
                }
                
                if (!cvvField.getText().matches("\\d{3,4}")) {
                    showError("CVV must be 3 or 4 digits");
                    return false;
                }
                
                if (expiryField.getText().trim().isEmpty()) {
                    showError("Please enter the expiry date (MM/YY)");
                    return false;
                }
                
                if (!expiryField.getText().matches("(0[1-9]|1[0-2])/\\d{2}")) {
                    showError("Expiry date must be in MM/YY format");
                    return false;
                }
            }
            
            return true;
        }
        
        private void showError(String message) {
            JOptionPane.showMessageDialog(PaymentPanel.this,
                message, "Payment Validation Error", JOptionPane.ERROR_MESSAGE);
        }
        
        private String generateSeatNumber() {
            int row = (int)(Math.random() * 30) + 1;
            char seat = (char)('A' + (int)(Math.random() * 6));
            return row + String.valueOf(seat);
        }
    }
}