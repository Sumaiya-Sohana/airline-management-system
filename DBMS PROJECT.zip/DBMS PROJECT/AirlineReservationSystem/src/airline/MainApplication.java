package airline;

import javax.swing.*;
import java.awt.*;

public class MainApplication extends JFrame {
    private CardLayout cardLayout;
    private JPanel cardPanel;
    private WelcomePanel welcomePanel;
    private PassengerInfoPanel passengerPanel;
    private FlightSelectionPanel flightPanel;
    private PaymentPanel paymentPanel;
    private ConfirmationPanel confirmationPanel;

    public MainApplication() {
        setTitle("Airline Reservation System");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Initialize panels
        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);
        
        welcomePanel = new WelcomePanel(this);
        passengerPanel = new PassengerInfoPanel(this);
        flightPanel = new FlightSelectionPanel(this);
        paymentPanel = new PaymentPanel(this);
        confirmationPanel = new ConfirmationPanel(this);
        
        // Add panels to card layout
        cardPanel.add(welcomePanel, "welcome");
        cardPanel.add(passengerPanel, "passenger");
        cardPanel.add(flightPanel, "flight");
        cardPanel.add(paymentPanel, "payment");
        cardPanel.add(confirmationPanel, "confirmation");
        
        add(cardPanel);
    }

    public void showPanel(String panelName) {
        cardLayout.show(cardPanel, panelName);
    }

    public void showNextPanel() {
        cardLayout.next(cardPanel);
    }

    public void showPreviousPanel() {
        cardLayout.previous(cardPanel);
    }

    public void resetToWelcome() {
        cardLayout.show(cardPanel, "welcome");
        ReservationData.clear();
        // Reset all panels
        passengerPanel.resetForm();
        flightPanel.resetForm();
        paymentPanel.resetForm();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                new MainApplication().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}