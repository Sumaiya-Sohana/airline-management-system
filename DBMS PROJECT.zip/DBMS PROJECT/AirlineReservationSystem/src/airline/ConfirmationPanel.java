package airline;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ConfirmationPanel extends JPanel {
    private MainApplication mainApp;
    private JTextArea detailsArea;
    
    public ConfirmationPanel(MainApplication mainApp) {
        this.mainApp = mainApp;
        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(240, 248, 255));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Header
        JLabel header = new JLabel("Booking Confirmed!", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 36));
        header.setForeground(new Color(0, 102, 0));
        
        // Details panel
        JPanel detailsPanel = new JPanel(new BorderLayout());
        detailsPanel.setBackground(new Color(240, 248, 255));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        
        detailsArea = new JTextArea();
        detailsArea.setEditable(false);
        detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        detailsArea.setBackground(new Color(240, 248, 255));
        detailsArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JScrollPane scrollPane = new JScrollPane(detailsArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        detailsPanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(240, 248, 255));
        
        JButton restartBtn = new JButton("Make Another Booking");
        restartBtn.setBackground(new Color(0, 102, 204));
        restartBtn.setForeground(Color.WHITE);
        restartBtn.addActionListener(e -> mainApp.resetToWelcome());
        
        buttonPanel.add(restartBtn);
        
        add(header, BorderLayout.NORTH);
        add(detailsPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    public void loadConfirmationDetails() {
        StringBuilder details = new StringBuilder();
        
        try (Connection conn = DBConnection.getConnection()) {
            // Get reservation details
            String resSql = "SELECT r.RID, TO_CHAR(r.ResDate, 'DD-MON-YYYY HH24:MI') AS BookingDate, " +
                           "r.Total_Amount, p.Pname, p.Email " +
                           "FROM Reservation r " +
                           "JOIN Reservation_Passenger rp ON r.RID = rp.RID " +
                           "JOIN Passenger p ON rp.PID = p.PID " +
                           "WHERE r.RID = ?";
            
            PreparedStatement resStmt = conn.prepareStatement(resSql);
            resStmt.setInt(1, ReservationData.getReservationId());
            ResultSet resRs = resStmt.executeQuery();
            
            if (resRs.next()) {
                details.append("=== BOOKING CONFIRMATION ===\n\n");
                details.append("Reservation ID: ").append(resRs.getInt("RID")).append("\n");
                details.append("Booking Date: ").append(resRs.getString("BookingDate")).append("\n");
                details.append("Passenger Name: ").append(resRs.getString("Pname")).append("\n");
                details.append("Total Amount: $").append(resRs.getDouble("Total_Amount")).append("\n\n");
                
                // Get flight details
                String flightSql = "SELECT f.FlightID, a1.Name AS FromAirport, a2.Name AS ToAirport, " +
                                  "TO_CHAR(f.Departure, 'DD-MON-YYYY HH24:MI') AS Departure, " +
                                  "TO_CHAR(f.Arrival, 'DD-MON-YYYY HH24:MI') AS Arrival, " +
                                  "t.SeatNo, t.Class " +
                                  "FROM Ticket t " +
                                  "JOIN Flight f ON t.FlightID = f.FlightID " +
                                  "JOIN Airport a1 ON f.FromAirport = a1.Code " +
                                  "JOIN Airport a2 ON f.ToAirport = a2.Code " +
                                  "WHERE t.RID = ?";
                
                PreparedStatement flightStmt = conn.prepareStatement(flightSql);
                flightStmt.setInt(1, ReservationData.getReservationId());
                ResultSet flightRs = flightStmt.executeQuery();
                
                if (flightRs.next()) {
                    details.append("=== FLIGHT DETAILS ===\n\n");
                    details.append("Flight Number: ").append(flightRs.getInt("FlightID")).append("\n");
                    details.append("Route: ").append(flightRs.getString("FromAirport"))
                           .append(" to ").append(flightRs.getString("ToAirport")).append("\n");
                    details.append("Departure: ").append(flightRs.getString("Departure")).append("\n");
                    details.append("Arrival: ").append(flightRs.getString("Arrival")).append("\n");
                    details.append("Seat: ").append(flightRs.getString("SeatNo")).append(" (")
                           .append(flightRs.getString("Class")).append(" Class)\n\n");
                }
                
                // Add thank you message
                details.append("Thank you for choosing SkyWings Airlines!\n");
                details.append("A confirmation email has been sent to: ").append(resRs.getString("Email"));
            }
            
            detailsArea.setText(details.toString());
            
        } catch (SQLException ex) {
            detailsArea.setText("Error loading booking details. Please contact customer service.");
            JOptionPane.showMessageDialog(this,
                "Error loading confirmation details: " + ex.getMessage(), "Database Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
}