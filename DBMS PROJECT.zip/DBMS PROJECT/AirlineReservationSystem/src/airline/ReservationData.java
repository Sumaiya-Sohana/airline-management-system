package airline;

public class ReservationData {
    private static int passengerId;
    private static int selectedFlightId;
    private static int reservationId;
    
    public static int getPassengerId() { return passengerId; }
    public static void setPassengerId(int id) { passengerId = id; }
    
    public static int getSelectedFlightId() { return selectedFlightId; }
    public static void setSelectedFlightId(int id) { selectedFlightId = id; }
    
    public static int getReservationId() { return reservationId; }
    public static void setReservationId(int id) { reservationId = id; }
    
    public static void clear() {
        passengerId = 0;
        selectedFlightId = 0;
        reservationId = 0;
    }
}