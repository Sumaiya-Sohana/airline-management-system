-- Clean up existing objects (if any)
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE Ticket CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE Payment CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE Reservation_Passenger CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE Reservation CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE Passenger CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE Flight CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE Airplane CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE Airport CASCADE CONSTRAINTS';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/

BEGIN
   EXECUTE IMMEDIATE 'DROP SEQUENCE passenger_seq';
   EXECUTE IMMEDIATE 'DROP SEQUENCE reservation_seq';
   EXECUTE IMMEDIATE 'DROP SEQUENCE payment_seq';
   EXECUTE IMMEDIATE 'DROP SEQUENCE airplane_seq';
   EXECUTE IMMEDIATE 'DROP SEQUENCE flight_seq';
   EXECUTE IMMEDIATE 'DROP SEQUENCE ticket_seq';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/

-- Create Tables
CREATE TABLE Passenger (
    PID NUMBER PRIMARY KEY,
    Pname VARCHAR2(100) NOT NULL,
    Phone VARCHAR2(20) NOT NULL,
    DOB DATE,
    City VARCHAR2(50),
    Email VARCHAR2(100),
    Gender VARCHAR2(10) CHECK (Gender IN ('Male', 'Female', 'Other')),
    PassportNo VARCHAR2(20),
    Nationality VARCHAR2(50),
    Created_At TIMESTAMP DEFAULT SYSTIMESTAMP
);

CREATE TABLE Airport (
    Code VARCHAR2(10) PRIMARY KEY,
    Name VARCHAR2(100) NOT NULL,
    City VARCHAR2(50) NOT NULL,
    Country VARCHAR2(50) NOT NULL
);

CREATE TABLE Airplane (
    AID NUMBER PRIMARY KEY,
    Model VARCHAR2(100) NOT NULL,
    Capacity NUMBER NOT NULL,
    Manufacturer VARCHAR2(100),
    Last_Maintenance DATE
);

CREATE TABLE Flight (
    FlightID NUMBER PRIMARY KEY,
    FromAirport VARCHAR2(10) NOT NULL,
    ToAirport VARCHAR2(10) NOT NULL,
    Departure TIMESTAMP NOT NULL,
    Arrival TIMESTAMP NOT NULL,
    AID NUMBER NOT NULL,
    Base_Price NUMBER(10,2) NOT NULL,
    Status VARCHAR2(20) DEFAULT 'Scheduled' CHECK (Status IN ('Scheduled', 'Delayed', 'Cancelled', 'Completed')),
    FOREIGN KEY (FromAirport) REFERENCES Airport(Code),
    FOREIGN KEY (ToAirport) REFERENCES Airport(Code),
    FOREIGN KEY (AID) REFERENCES Airplane(AID)
);

CREATE TABLE Reservation (
    RID NUMBER PRIMARY KEY,
    ResDate DATE DEFAULT SYSDATE,
    Status VARCHAR2(20) DEFAULT 'Confirmed' CHECK (Status IN ('Confirmed', 'Cancelled', 'Pending')),
    Total_Amount NUMBER(10,2),
    Notes VARCHAR2(500),
    Created_At TIMESTAMP DEFAULT SYSTIMESTAMP
);

CREATE TABLE Reservation_Passenger (
    RID NUMBER,
    PID NUMBER,
    PRIMARY KEY (RID, PID),
    FOREIGN KEY (RID) REFERENCES Reservation(RID) ON DELETE CASCADE,
    FOREIGN KEY (PID) REFERENCES Passenger(PID) ON DELETE CASCADE
);

CREATE TABLE Payment (
    PayID NUMBER PRIMARY KEY,
    RID NUMBER,
    Amount NUMBER(10,2) NOT NULL,
    PDate DATE DEFAULT SYSDATE,
    Method VARCHAR2(20) CHECK (Method IN ('Credit Card', 'Debit Card', 'Net Banking', 'UPI', 'Cash')),
    TransactionID VARCHAR2(100) NOT NULL,
    Status VARCHAR2(20) DEFAULT 'Completed' CHECK (Status IN ('Completed', 'Failed', 'Refunded')),
    Card_Last_Four VARCHAR2(4),
    Payment_Gateway VARCHAR2(50),
    FOREIGN KEY (RID) REFERENCES Reservation(RID) ON DELETE CASCADE
);

CREATE TABLE Ticket (
    TID NUMBER PRIMARY KEY,
    RID NUMBER,
    FlightID NUMBER,
    SeatNo VARCHAR2(10) NOT NULL,
    Class VARCHAR2(20) CHECK (Class IN ('Economy', 'Business', 'First Class')),
    Price NUMBER(10,2) NOT NULL,
    Status VARCHAR2(20) DEFAULT 'Booked' CHECK (Status IN ('Booked', 'Cancelled', 'Boarded')),
    UNIQUE (FlightID, SeatNo),
    FOREIGN KEY (RID) REFERENCES Reservation(RID) ON DELETE CASCADE,
    FOREIGN KEY (FlightID) REFERENCES Flight(FlightID)
);

-- Create Sequences
CREATE SEQUENCE passenger_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE reservation_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE payment_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE airplane_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE flight_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE ticket_seq START WITH 1 INCREMENT BY 1;

-- Create Triggers
CREATE OR REPLACE TRIGGER trg_bi_passenger
BEFORE INSERT ON Passenger
FOR EACH ROW
BEGIN
    SELECT passenger_seq.NEXTVAL INTO :new.PID FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_bi_reservation
BEFORE INSERT ON Reservation
FOR EACH ROW
BEGIN
    SELECT reservation_seq.NEXTVAL INTO :new.RID FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_bi_payment
BEFORE INSERT ON Payment
FOR EACH ROW
BEGIN
    SELECT payment_seq.NEXTVAL INTO :new.PayID FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_bi_airplane
BEFORE INSERT ON Airplane
FOR EACH ROW
BEGIN
    SELECT airplane_seq.NEXTVAL INTO :new.AID FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_bi_flight
BEFORE INSERT ON Flight
FOR EACH ROW
BEGIN
    SELECT flight_seq.NEXTVAL INTO :new.FlightID FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_bi_ticket
BEFORE INSERT ON Ticket
FOR EACH ROW
BEGIN
    SELECT ticket_seq.NEXTVAL INTO :new.TID FROM dual;
END;
/

-- Create Indexes
CREATE INDEX idx_flight_departure ON Flight(Departure);
CREATE INDEX idx_flight_route ON Flight(FromAirport, ToAirport);
CREATE INDEX idx_payment_date ON Payment(PDate);
CREATE INDEX idx_payment_status ON Payment(Status);
CREATE INDEX idx_passenger_name ON Passenger(Pname);
CREATE INDEX idx_passenger_phone ON Passenger(Phone);

-- Insert Sample Data (in correct order to maintain referential integrity)
-- 1. Airports
INSERT INTO Airport VALUES ('JFK', 'John F. Kennedy International Airport', 'New York', 'USA');
INSERT INTO Airport VALUES ('LAX', 'Los Angeles International Airport', 'Los Angeles', 'USA');
INSERT INTO Airport VALUES ('DXB', 'Dubai International Airport', 'Dubai', 'UAE');
INSERT INTO Airport VALUES ('LHR', 'Heathrow Airport', 'London', 'UK');
INSERT INTO Airport VALUES ('HND', 'Haneda Airport', 'Tokyo', 'Japan');
INSERT INTO Airport VALUES ('SYD', 'Sydney Airport', 'Sydney', 'Australia');
INSERT INTO Airport VALUES ('DEL', 'Indira Gandhi International Airport', 'Delhi', 'India');
INSERT INTO Airport VALUES ('SIN', 'Changi Airport', 'Singapore', 'Singapore');
COMMIT;

-- 2. Airplanes
INSERT INTO Airplane (Model, Capacity, Manufacturer, Last_Maintenance) 
VALUES ('Boeing 737', 180, 'Boeing', TO_DATE('01-JAN-2023', 'DD-MON-YYYY'));

INSERT INTO Airplane (Model, Capacity, Manufacturer, Last_Maintenance) 
VALUES ('Airbus A320', 150, 'Airbus', TO_DATE('15-FEB-2023', 'DD-MON-YYYY'));

INSERT INTO Airplane (Model, Capacity, Manufacturer, Last_Maintenance) 
VALUES ('Boeing 787', 250, 'Boeing', TO_DATE('10-MAR-2023', 'DD-MON-YYYY'));

INSERT INTO Airplane (Model, Capacity, Manufacturer, Last_Maintenance) 
VALUES ('Airbus A380', 550, 'Airbus', TO_DATE('05-APR-2023', 'DD-MON-YYYY'));
COMMIT;

-- 3. Flights (using future dates)
INSERT INTO Flight (FromAirport, ToAirport, Departure, Arrival, AID, Base_Price, Status)
VALUES ('JFK', 'LAX', 
        SYSTIMESTAMP + INTERVAL '1' DAY,  -- Tomorrow
        SYSTIMESTAMP + INTERVAL '1' DAY + INTERVAL '5' HOUR,
        1, 299.99, 'Scheduled');

INSERT INTO Flight (FromAirport, ToAirport, Departure, Arrival, AID, Base_Price, Status)
VALUES ('LAX', 'JFK', 
        SYSTIMESTAMP + INTERVAL '2' DAY,  -- Day after tomorrow
        SYSTIMESTAMP + INTERVAL '2' DAY + INTERVAL '5' HOUR,
        2, 349.99, 'Scheduled');

INSERT INTO Flight (FromAirport, ToAirport, Departure, Arrival, AID, Base_Price, Status)
VALUES ('JFK', 'LHR', 
        SYSTIMESTAMP + INTERVAL '3' DAY,
        SYSTIMESTAMP + INTERVAL '3' DAY + INTERVAL '7' HOUR,
        3, 799.99, 'Scheduled');

INSERT INTO Flight (FromAirport, ToAirport, Departure, Arrival, AID, Base_Price, Status)
VALUES ('HND', 'DXB', 
        SYSTIMESTAMP + INTERVAL '4' DAY,
        SYSTIMESTAMP + INTERVAL '4' DAY + INTERVAL '10' HOUR,
        4, 899.99, 'Scheduled');

INSERT INTO Flight (FromAirport, ToAirport, Departure, Arrival, AID, Base_Price, Status)
VALUES ('DXB', 'HND', 
        SYSTIMESTAMP + INTERVAL '5' DAY,
        SYSTIMESTAMP + INTERVAL '5' DAY + INTERVAL '10' HOUR,
        4, 849.99, 'Scheduled');

INSERT INTO Flight (FromAirport, ToAirport, Departure, Arrival, AID, Base_Price, Status)
VALUES ('SYD', 'SIN', 
        SYSTIMESTAMP + INTERVAL '6' DAY,
        SYSTIMESTAMP + INTERVAL '6' DAY + INTERVAL '8' HOUR,
        2, 499.99, 'Scheduled');
COMMIT;

-- 4. Sample Passengers
INSERT INTO Passenger (Pname, Phone, DOB, City, Email, Gender, PassportNo, Nationality)
VALUES ('John Smith', '1234567890', TO_DATE('15-MAY-1985', 'DD-MON-YYYY'), 
        'New York', 'john.smith@email.com', 'Male', 'P12345678', 'USA');

INSERT INTO Passenger (Pname, Phone, DOB, City, Email, Gender, PassportNo, Nationality)
VALUES ('Sarah Johnson', '9876543210', TO_DATE('20-SEP-1990', 'DD-MON-YYYY'), 
        'Los Angeles', 'sarah.j@email.com', 'Female', 'P87654321', 'USA');

INSERT INTO Passenger (Pname, Phone, DOB, City, Email, Gender, PassportNo, Nationality)
VALUES ('Mohammed Al-Farsi', '971501234567', TO_DATE('10-JUL-1978', 'DD-MON-YYYY'), 
        'Dubai', 'm.alfarsi@email.com', 'Male', 'P11223344', 'UAE');

INSERT INTO Passenger (Pname, Phone, DOB, City, Email, Gender, PassportNo, Nationality)
VALUES ('Priya Patel', '919876543210', TO_DATE('05-MAR-1995', 'DD-MON-YYYY'), 
        'Mumbai', 'priya.p@email.com', 'Female', 'P55667788', 'India');
COMMIT;

-- Verification Queries
SELECT 'Airports' AS Table_Name, COUNT(*) AS Record_Count FROM Airport
UNION ALL
SELECT 'Airplanes', COUNT(*) FROM Airplane
UNION ALL
SELECT 'Flights', COUNT(*) FROM Flight
UNION ALL
SELECT 'Passengers', COUNT(*) FROM Passenger;

SELECT DISTINCT
    p.PID as "Passenger_Id",
    p.Pname AS "Passenger_Name",
    p.Phone AS "Phone",
    p.Email AS "Email",
    COUNT(r.RID) AS "Total_Bookings"
FROM 
    Passenger p
JOIN 
    Reservation_Passenger rp ON p.PID = rp.PID
JOIN 
    Reservation r ON rp.RID = r.RID
WHERE 
    r.Status = 'Confirmed'
GROUP BY 
    p.PID, p.Pname, p.Phone, p.Email
ORDER BY 
    p.PID;
    

